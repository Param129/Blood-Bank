const express =require('express');
const app= express()
const path =require('path')
// const sqlite3 = require('sqlite3').verbose();
const bparser =require('body-parser');
app.set('view engine','ejs');
app.use(bparser.urlencoded({extended: false}));
// app.set('views',path.join(__dirname,'views'));
//  database ------->
// const db_name =path.join(__dirname,'data','psdapp.db');
//  const db = new sqlite3.Database(db_name,err=>{
//    if(err){
//       console.log(err.message);
//    }
//    console.log("connected");
//  })


app.post('/fo',(req,res)=>{
  res.render('t1');
  console.log(req.body.example);
})

app.listen(3000)

